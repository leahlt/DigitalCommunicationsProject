This folder contains all files required for our audio transmission.

Solution .sof file is in AudioTransmission/DigitalCommunicationProject-integration2/Part3/output_files and is called
Final_Audio_Integration.sof

All testbench files can be simulated in ModelSim

Folder: audioTransmission
AWGN_noise.v
AWGN_noise_tb.v
Altera_UP_Audio_Bit_Counter.v
Altera_UP_Audio_In_Deserializer.v
Altera_UP_Audio_Out_Deserializer.v
Altera_UP_Audio_UP_Clock_Edge.v
Altera_UP_I2C.v
Altera_UP_I2C_AV_Auto_Initialize.v
Altera_UP_I2C_DC_Auto_Initialize.v
Altera_UP_I2C_LCM_Auto_Initialize.v
Altera_UP_SYNC_FIFO.v
Altera_UP_Slow_Clock_Generator.v
audio_integration_tb.v
BPSK.v
Modulator_tb.v
Audio_and_video_config.v
Audio_codec.v
Clock_generator.v
part3.v
Alaw.v
deAlaw.v
Alaw_tb.v
BER.v
BER_tb.v

Folder: rc4
Decrypt.v
Encrypt.v
Rc4.v
Rc4_top.v
Rc4_top_tb.v

Folder: ErrorCorrectionCoding
BCH_control.v
BCH_enc.v
BCH_dec.v
