# DigitalCommunicationsProject
FPGA and Simulink Digital Communications System

top.v is the top level module for this system and should implement/call the blocks of the communication system
